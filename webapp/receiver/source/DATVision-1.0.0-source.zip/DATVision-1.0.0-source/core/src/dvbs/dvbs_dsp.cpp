// DVB-S/S2 receiver signal path, see dvbs_dsp.h.
#include "dvbs_dsp.h"
#include "dvbs_simd.h"
#include "dect2/dsp/simd.h"
#include "dect2/dvbs/dvbs_gen.h"     // rrcAt
#include <algorithm>
#include <cmath>
#include <cstring>
#include "dect2/common/mathconst.h"
#include "dect2/common/window.h"

namespace dect2 {
namespace dvbs {

namespace {
using dect2::math::kPi;

double besselI0(double x) { return dect2::window::besselI0(x, 60, 1e-12); }
double kaiser(double x, double beta) {            // x in [-1, 1]
    if (std::fabs(x) >= 1) return 0;
    return besselI0(beta * std::sqrt(1 - x * x)) / besselI0(beta);
}
double sinc(double x) { return std::fabs(x) < 1e-12 ? 1.0 : std::sin(kPi * x) / (kPi * x); }
}

// ============================================================================ mixer and DC removal
void MixDc::makeTable() {
    for (int k = 0; k < kBlock; k++) { tc_[k] = (float)std::cos(k * step_); ts_[k] = -(float)std::sin(k * step_); }
}

void MixDc::configure(double fs, double freqHz) {
    fs_ = fs;
    step_ = 2 * kPi * freqHz / fs;
    makeTable();
    reset();
}

// Blocks of 64 samples: one phasor per block, the rest from a table, so that the loop has no chain of dependent operations; the DC estimate is the
// running mean of the blocks (a time constant of about 131 000 samples) and is applied to the next block
void MixDc::process(const cf32* x, size_t n, SplitBuf& out) {
    const size_t base = out.size();
    out.resize(base + n);
    float* re = out.re.data() + base;
    float* im = out.im.data() + base;
    if (!dcInit_ && n) { double a = 0, b = 0; for (size_t i = 0; i < n; i++) { a += x[i].real(); b += x[i].imag(); } dcRe_ = (float)(a / n); dcIm_ = (float)(b / n); dcInit_ = true; }
    const float mu = (float)kBlock / 131072.f;
    const bool rotate = std::fabs(step_) > 1e-12;
    size_t i = 0;
    while (i < n) {
        const size_t m = std::min<size_t>(kBlock, n - i);
        const float c0 = (float)std::cos(-phase_), s0 = (float)std::sin(-phase_);
        const float dr = dcRe_, di = dcIm_;
        float sr = 0.f, si = 0.f;
        const float* xp = reinterpret_cast<const float*>(x + i);
        if (rotate) {
            for (size_t k = 0; k < m; k++) {
                const float xr = xp[2 * k] - dr, xi = xp[2 * k + 1] - di;
                sr += xp[2 * k]; si += xp[2 * k + 1];
                const float a = c0 * tc_[k] - s0 * ts_[k], b = c0 * ts_[k] + s0 * tc_[k];
                re[i + k] = xr * a - xi * b;
                im[i + k] = xr * b + xi * a;
            }
        } else {
            for (size_t k = 0; k < m; k++) {
                sr += xp[2 * k]; si += xp[2 * k + 1];
                re[i + k] = xp[2 * k] - dr;
                im[i + k] = xp[2 * k + 1] - di;
            }
        }
        dcRe_ += (sr / (float)m - dcRe_) * mu;
        dcIm_ += (si / (float)m - dcIm_) * mu;
        phase_ = std::fmod(phase_ + (double)m * step_, 2 * kPi);
        i += m;
    }
}

// ============================================================================ half-band decimator
namespace {
constexpr int kHbJ = 8;     // odd taps at offsets 1, 3, ..., 2J-1 on each side
}

Halfband::Halfband() {
    h_.assign(kHbJ, 0.f);
    const double beta = 7.0, half = 2.0 * kHbJ;
    double sum = 0.5;
    for (int j = 0; j < kHbJ; j++) {
        const int off = 2 * j + 1;
        const double v = 0.5 * sinc(off / 2.0) * kaiser(off / (half + 1), beta);
        h_[j] = (float)v;
        sum += 2 * v;
    }
    const float g = (float)(1.0 / sum);          // unit gain at DC
    for (auto& v : h_) v *= g;
    centre_ = 0.5f * g;
    reset();
}

void Halfband::reset() {
    hist_.clear();
    hist_.re.assign(2 * kHbJ - 1, 0.f);
    hist_.im.assign(2 * kHbJ - 1, 0.f);
    phase_ = 2 * kHbJ - 1;
}

void Halfband::process(const SplitBuf& in, size_t n, SplitBuf& out) {
    hist_.re.insert(hist_.re.end(), in.re.begin(), in.re.begin() + (std::ptrdiff_t)n);
    hist_.im.insert(hist_.im.end(), in.im.begin(), in.im.begin() + (std::ptrdiff_t)n);
    const size_t reach = 2 * kHbJ - 1;
    const size_t sz = hist_.size();
    if (sz <= phase_ + reach) return;
    const size_t outs = (sz - 1 - reach - phase_) / 2 + 1;
    const size_t base = out.size();
    out.resize(base + outs);
    const float* xr = hist_.re.data();
    const float* xi = hist_.im.data();
    for (size_t m = 0; m < outs; m++) {
        const size_t c = phase_ + 2 * m;
        float sr = centre_ * xr[c], si = centre_ * xi[c];
        for (int j = 0; j < kHbJ; j++) {
            const size_t o = 2 * (size_t)j + 1;
            sr += h_[j] * (xr[c - o] + xr[c + o]);
            si += h_[j] * (xi[c - o] + xi[c + o]);
        }
        out.re[base + m] = sr; out.im[base + m] = si;
    }
    phase_ += 2 * outs;
    const size_t drop = phase_ - reach;
    hist_.eraseFront(drop);
    phase_ -= drop;
}

// ============================================================================ polyphase resampler
void PolyResampler::design(double r) {
    // lowpass at half the output rate (or half the input rate when interpolating)
    const double fc = 0.5 * std::min(1.0, 1.0 / r);
    int n = (int)std::ceil(8.0 * std::max(r, 1.5));
    n = std::max(16, std::min(64, (n + 7) / 8 * 8));
    taps_ = n;
    bank_.assign((size_t)phases_ * n, 0.f);
    const double beta = 7.0;
    for (int p = 0; p < phases_; p++) {
        double sum = 0;
        std::vector<double> t(n);
        for (int i = 0; i < n; i++) {
            const double tau = (double)p / phases_ + (n / 2 - 1 - i);
            t[i] = 2 * fc * sinc(2 * fc * tau) * kaiser(tau / (n / 2.0), beta);
            sum += t[i];
        }
        for (int i = 0; i < n; i++) bank_[(size_t)p * n + i] = (float)(t[i] / sum);
    }
}

void PolyResampler::configure(double ratio) {
    ratio_ = ratio;
    design(ratio);
    reset();
}

void PolyResampler::reset() {
    hist_.clear();
    hist_.re.assign(taps_ / 2, 0.f);
    hist_.im.assign(taps_ / 2, 0.f);
    pos_ = taps_ / 2 - 1;
}

void PolyResampler::process(const SplitBuf& in, size_t n, SplitBuf& out) {
    hist_.re.insert(hist_.re.end(), in.re.begin(), in.re.begin() + (std::ptrdiff_t)n);
    hist_.im.insert(hist_.im.end(), in.im.begin(), in.im.begin() + (std::ptrdiff_t)n);
    const int N = taps_;
    const double need = N / 2;
    const float* xr = hist_.re.data();
    const float* xi = hist_.im.data();
    // upper bound on the number of outputs
    const double avail = (double)hist_.size() - need - pos_;
    if (avail <= 0) return;
    const size_t cap = (size_t)(avail / ratio_) + 2;
    const size_t base = out.size();
    out.resize(base + cap);
    size_t produced = 0;
    while (pos_ + need < (double)hist_.size()) {
        const long i0 = (long)std::floor(pos_);
        const double fr = pos_ - (double)i0;
        int p = (int)(fr * phases_ + 0.5);
        long ii = i0;
        if (p >= phases_) { p = 0; ii++; }
        if (ii + N / 2 >= (long)hist_.size()) break;
        const float* h = &bank_[(size_t)p * N];
        const float* ar = xr + (ii - N / 2 + 1);
        const float* ai = xi + (ii - N / 2 + 1);
        float sv[2];
        dot2(h, ar, ai, N, sv);
        const float sr = sv[0], si = sv[1];
        if (produced >= cap) break;
        out.re[base + produced] = sr; out.im[base + produced] = si;
        produced++;
        pos_ += ratio_;
    }
    out.resize(base + produced);
    const long drop = (long)std::floor(pos_) - N / 2 + 1;
    if (drop > 0) { hist_.eraseFront((size_t)drop); pos_ -= (double)drop; }
}

// ============================================================================ matched filter and timing loop
void SymbolTimer::design(double alpha) {
    alpha_ = alpha;
    m_ = 2 * hs_;
    const int taps = 2 * m_;
    bank_.assign((size_t)phases_ * taps, 0.f);
    for (int p = 0; p < phases_; p++)
        for (int i = 0; i < taps; i++) bank_[(size_t)p * taps + i] = (float)(0.5 * rrcAt(0.5 * ((double)p / phases_ + (m_ - 1 - i)), alpha));
    kd_ = std::max(3.1 * alpha, 0.15);
    setLoop(bnt_, zeta_);
}

void SymbolTimer::configure(double rollOff, int halfSpanSymbols) {
    hs_ = halfSpanSymbols;
    design(rollOff);
    reset();
}

void SymbolTimer::setLoop(double bnT, double zeta) {
    bnt_ = bnT; zeta_ = zeta;
    const double th = bnT / (zeta + 1.0 / (4.0 * zeta));
    const double d = 1.0 + 2.0 * zeta * th + th * th;
    kp_ = 4.0 * zeta * th / d / kd_;
    ki_ = 4.0 * th * th / d / kd_;
}

void SymbolTimer::reset() {
    buf_.clear();
    t_ = m_;
    integ_ = 0;
    havePrev_ = false;
    power_ = 0; corr_ = 0; invPower_ = 1; gain_ = 1;
    errRms_ = 0; errMs_ = 0;
    count_ = 0;
}

void SymbolTimer::process(SplitBuf& in, std::vector<cf32>& out) {
    buf_.re.insert(buf_.re.end(), in.re.begin(), in.re.end());
    buf_.im.insert(buf_.im.end(), in.im.begin(), in.im.end());
    in.clear();
    const int taps = 2 * m_;
    const float* xr = buf_.re.data();
    const float* xi = buf_.im.data();
    const size_t outBase = out.size();
    // How many symbols fit in what we have (a symbol is about two samples; the loop corrections are tiny)
    const double lim = (double)buf_.size() - m_ - 1;
    out.resize(outBase + (size_t)std::max(0.0, (lim - t_) / 1.5) + 2);
    cf32* o = out.data() + outBase;
    size_t made = 0;
#if defined(DVBS_AVX2_DOT)
    const bool avx2 = cpuHasAvx2() && (taps & 7) == 0;
#endif
    double corrPrev = corr_;                 // the correction from the previous symbol's error is applied with a delay of one symbol, which
    float invPow = invPower_, gain = gain_;  // lets the filter outputs of consecutive symbols be computed without waiting for each other
    while (t_ < lim) {
        const long i0 = (long)t_;
        const double fr = t_ - (double)i0;
        int p = (int)(fr * phases_ + 0.5);
        long ii = i0;
        if (p >= phases_) { p = 0; ii++; }
        const float* h = &bank_[(size_t)p * taps];
        const long s0 = ii - m_ + 1;
        float dv[4];
#if defined(DVBS_AVX2_DOT)
        if (avx2) dot4Avx2(h, xr + s0, xi + s0, xr + s0 - 1, xi + s0 - 1, taps, dv); else
#endif
        dot4(h, xr + s0, xi + s0, xr + s0 - 1, xi + s0 - 1, taps, dv);
        const float yr = dv[0], yi = dv[1], mr = dv[2], mi = dv[3];
        // the next timing instant, from the correction known so far
        t_ += 2.0 * (1.0 - corrPrev);
        const float pw = yr * yr + yi * yi;
        if (count_ < 64) {                    // quick start of the power estimate
            power_ += (pw - power_) / (float)(count_ + 1);
            invPow = power_ > 0 ? 1.f / power_ : 1.f; gain = std::sqrt(invPow);
        } else {
            power_ += (pw - power_) * (1.f / 4096.f);
            if ((count_ & 15) == 0) { invPow = 1.f / power_; gain = std::sqrt(invPow); }
        }
        if (havePrev_) {
            // Gardner: positive when the sampling instant is late
            float e = (mr * (yr - prevRe_) + mi * (yi - prevIm_)) * invPow;
            e = std::max(-2.f, std::min(2.f, e));
            integ_ += ki_ * e;
            corrPrev = kp_ * e + integ_;
            errMs_ += (e * e - errMs_) * 0.002f;
        }
        prevRe_ = yr; prevIm_ = yi; havePrev_ = true;
        o[made++] = cf32(yr * gain, yi * gain);
        count_++;
    }
    corr_ = corrPrev; invPower_ = invPow; gain_ = gain;
    errRms_ = std::sqrt(errMs_);
    out.resize(outBase + made);
    const long drop = (long)std::floor(t_) - m_ - 1;
    if (drop > 0) { buf_.eraseFront((size_t)drop); t_ -= (double)drop; }
}

} // namespace dvbs
} // namespace dect2
