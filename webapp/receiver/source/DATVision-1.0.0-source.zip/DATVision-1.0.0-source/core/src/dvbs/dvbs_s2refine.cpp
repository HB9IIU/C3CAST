// DVB-S2 receiver: decisions and phase refinement, see dvbs_s2refine.h.
#include "dvbs_s2refine.h"
#include "dect2/dvbs/dvbs_s2.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <mutex>
#if defined(__SSE2__) && !defined(DECT2_NO_SIMD)
#include <emmintrin.h>
#endif
#include "dect2/common/mathconst.h"

namespace dect2 {
namespace dvbs {

void NearestPoint::build(const cf32* p, int count) {
    pts_ = p; n_ = count;
    float mx = 0.f;
    for (int i = 0; i < count; i++) mx = std::max(mx, std::abs(p[i]));
    lim_ = std::max(1.5f, mx * 1.35f);
    grid_ = count <= 32 ? 128 : count <= 64 ? 256 : 512;
    scale_ = (float)grid_ / (2.f * lim_);
    idx_.assign((size_t)grid_ * grid_, 0);
    idx2_.assign((size_t)grid_ * grid_, 0);
    for (int iy = 0; iy < grid_; iy++)
        for (int ix = 0; ix < grid_; ix++) {
            const float re = ((float)ix + 0.5f) / scale_ - lim_, im = ((float)iy + 0.5f) / scale_ - lim_;
            float bd = 1e30f, bd2 = 1e30f; int bi = 0, bi2 = 0;
            for (int i = 0; i < count; i++) {
                const float a = re - p[i].real(), b = im - p[i].imag(), d = a * a + b * b;
                if (d < bd) { bd2 = bd; bi2 = bi; bd = d; bi = i; }
                else if (d < bd2) { bd2 = d; bi2 = i; }
            }
            idx_[(size_t)iy * grid_ + (size_t)ix] = (uint8_t)bi;
            idx2_[(size_t)iy * grid_ + (size_t)ix] = (uint8_t)bi2;
        }
}

const NearestPoint& nearestPoint(int mod, int rate) {
    static std::mutex mu;
    static std::map<int, NearestPoint*> cache;
    std::lock_guard<std::mutex> lk(mu);
    const int key = mod < 2 && !s2IsS2x(rate) ? mod * 1000 : mod * 1000 + rate;
    auto it = cache.find(key);
    if (it != cache.end()) return *it->second;
    auto* np = new NearestPoint();          // kept for the life of the program: callers keep references
    np->build(s2Constellation(mod, rate), s2ConstellationSize(mod));
    cache[key] = np;
    return *np;
}

namespace {
inline float fexpNeg(float x) {        // e^x for x <= 0
    x = std::max(x, -60.f);
    const float t = x * 1.44269504f;
    const float fi = std::floor(t), f = t - fi;
    const float p = 1.f + f * (0.69314718f + f * (0.24022651f + f * (0.05550411f + f * 0.00961813f)));
    union { float f; int32_t i; } u;
    u.i = ((int32_t)fi + 127) << 23;
    return p * u.f;
}
inline float ftanhf(float x) {
    const float ax = std::min(std::fabs(x), 12.f);
    const float e = fexpNeg(-2.f * ax);
    const float t = (1.f - e) / (1.f + e);
    return x < 0 ? -t : t;
}

// e[i] = fexpNeg(w[i]) for n a multiple of 4: the same operations in the same order, four at a time, so the values are bit for bit those of fexpNeg
inline void fexpNegN(const float* w, float* e, int n) {
#if defined(__SSE2__) && !defined(DECT2_NO_SIMD)
    const __m128 lo = _mm_set1_ps(-60.f), l2e = _mm_set1_ps(1.44269504f), one = _mm_set1_ps(1.f);
    const __m128 c1 = _mm_set1_ps(0.69314718f), c2 = _mm_set1_ps(0.24022651f), c3 = _mm_set1_ps(0.05550411f), c4 = _mm_set1_ps(0.00961813f);
    for (int i = 0; i < n; i += 4) {
        const __m128 x = _mm_max_ps(_mm_loadu_ps(w + i), lo);
        const __m128 t = _mm_mul_ps(x, l2e);
        const __m128i tr = _mm_cvttps_epi32(t);
        const __m128 trf = _mm_cvtepi32_ps(tr);
        const __m128 gt = _mm_cmpgt_ps(trf, t);                      // truncation went up (t < 0): floor is one less
        const __m128 fi = _mm_sub_ps(trf, _mm_and_ps(gt, one));
        const __m128i fii = _mm_add_epi32(tr, _mm_castps_si128(gt));
        const __m128 f = _mm_sub_ps(t, fi);
        __m128 pp = _mm_add_ps(c3, _mm_mul_ps(f, c4));
        pp = _mm_add_ps(c2, _mm_mul_ps(f, pp));
        pp = _mm_add_ps(c1, _mm_mul_ps(f, pp));
        pp = _mm_add_ps(one, _mm_mul_ps(f, pp));
        const __m128 u = _mm_castsi128_ps(_mm_slli_epi32(_mm_add_epi32(fii, _mm_set1_epi32(127)), 23));
        _mm_storeu_ps(e + i, _mm_mul_ps(pp, u));
    }
#else
    for (int i = 0; i < n; i++) e[i] = fexpNeg(w[i]);
#endif
}
} // namespace

float s2RefinePhase(cf32* x, int n, int mod, int rate, float sigma2, int W, const std::vector<PhaseMark>& marks, int iterations) {
    (void)marks;
    if (n < 4 * W || W < 4) return 0.f;
    const cf32* c = s2Constellation(mod, rate);
    const int P = s2ConstellationSize(mod);
    const NearestPoint& np = nearestPoint(mod, rate);
    float dmin = 1e9f;
    for (int i = 0; i < P; i++) for (int j = i + 1; j < P; j++) dmin = std::min(dmin, std::abs(c[i] - c[j]));
    const bool soft = sigma2 > (dmin * 0.125f) * (dmin * 0.125f);
    const float invS = 1.f / std::max(sigma2, 1e-4f);
    const int nb = n / W;
    std::vector<cf32> acc((size_t)nb), sm((size_t)nb);
    std::vector<float> eps((size_t)n);
    double sq = 0;
    for (int it = 0; it < iterations; it++) {
        for (int b = 0; b < nb; b++) {
            const int k0 = b * W, k1 = b == nb - 1 ? n : k0 + W;
            float ar = 0, ai = 0;
            for (int k = k0; k < k1; k++) {
                const float xr = x[k].real(), xi = x[k].imag();
                float er, ei;
                if (!soft) { const cf32 e = c[np.index(xr, xi)]; er = e.real(); ei = e.imag(); }
                else if (mod == kQpsk) { er = dect2::math::k1OverSqrt2f * ftanhf(dect2::math::k1OverSqrt2f * invS * xr); ei = dect2::math::k1OverSqrt2f * ftanhf(dect2::math::k1OverSqrt2f * invS * xi); }
                else if (P > 32) {
                    // the dense S2X constellations: the two nearest points carry the expectation
                    int i1, i2;
                    np.index2(xr, xi, i1, i2);
                    const float d1 = (xr - c[i1].real()) * (xr - c[i1].real()) + (xi - c[i1].imag()) * (xi - c[i1].imag());
                    const float d2 = (xr - c[i2].real()) * (xr - c[i2].real()) + (xi - c[i2].imag()) * (xi - c[i2].imag());
                    const float e = fexpNeg(-(d2 - d1) * 0.5f * invS), iw = 1.f / (1.f + e);
                    er = (c[i1].real() + e * c[i2].real()) * iw; ei = (c[i1].imag() + e * c[i2].imag()) * iw;
                } else {
                    float w[32], ev[32], mx = -1e30f;
                    const float h = 0.5f * invS;
                    for (int i = 0; i < P; i++) { const float a = xr - c[i].real(), bb = xi - c[i].imag(); w[i] = -(a * a + bb * bb) * h; mx = std::max(mx, w[i]); }
                    const int Pv = (P + 3) & ~3;
                    for (int i = 0; i < P; i++) w[i] -= mx;
                    for (int i = P; i < Pv; i++) w[i] = -60.f;
                    fexpNegN(w, ev, Pv);
                    float sw = 0, sr = 0, si = 0;
                    for (int i = 0; i < P; i++) { const float e = ev[i]; sw += e; sr += e * c[i].real(); si += e * c[i].imag(); }
                    er = sr / sw; ei = si / sw;
                }
                ar += xr * er + xi * ei;           // x conj(E)
                ai += xi * er - xr * ei;
            }
            acc[(size_t)b] = cf32(ar, ai);
        }
        // zero lag smoothing across the blocks: a 1 2 1 weighted vector sum (the weights are the block magnitudes, so unreliable blocks count little)
        for (int b = 0; b < nb; b++) {
            cf32 s = 2.f * acc[(size_t)b];
            if (b > 0) s += acc[(size_t)b - 1];
            if (b + 1 < nb) s += acc[(size_t)b + 1];
            sm[(size_t)b] = s;
        }
        // phase per block centre, linear interpolation in between (the phase is unwrapped along the way)
        std::vector<float> ph((size_t)nb);
        float prev = 0;
        for (int b = 0; b < nb; b++) {
            float a = std::abs(sm[(size_t)b]) > 1e-9f ? std::arg(sm[(size_t)b]) : prev;
            while (a - prev > 3.14159265f) a -= 6.2831853f;
            while (a - prev < -3.14159265f) a += 6.2831853f;
            ph[(size_t)b] = prev = a;
        }
        // the correction is linear between block centres: a rotor with a constant step inside each stretch, renewed at the stretch start
        {
            int k = 0;
            while (k < n) {
                const float t = ((float)k - 0.5f * (float)W) / (float)W;
                int b0 = (int)std::floor(t);
                int b1 = b0 + 1;
                int kEnd;
                float e0, slope;
                if (b0 < 0) { e0 = ph[0]; slope = 0.f; kEnd = std::min(n, W / 2); }
                else if (b1 >= nb) { e0 = ph[(size_t)nb - 1]; slope = 0.f; kEnd = n; }
                else {
                    const float f = t - (float)b0;
                    e0 = ph[(size_t)b0] * (1.f - f) + ph[(size_t)b1] * f;
                    slope = (ph[(size_t)b1] - ph[(size_t)b0]) / (float)W;
                    kEnd = std::min(n, b1 * W + W / 2);
                }
                if (kEnd <= k) kEnd = k + 1;
                cf32 rot(std::cos(e0), -std::sin(e0));
                const cf32 stp(std::cos(slope), -std::sin(slope));
                for (int j = k; j < kEnd; j++) { eps[(size_t)j] = e0 + slope * (float)(j - k); x[j] *= rot; rot *= stp; }
                k = kEnd;
            }
        }
        if (it == iterations - 1) for (int k = 0; k < n; k++) sq += (double)eps[(size_t)k] * eps[(size_t)k];
    }
    return (float)std::sqrt(sq / n);
}

} // namespace dvbs
} // namespace dect2
